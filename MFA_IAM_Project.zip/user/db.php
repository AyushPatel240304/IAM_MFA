<?php
    $conn =  mysqli_connect("localhost","root","","login");

    // if ($conn){
    //     echo "Connected";
    // }
    // else {
    //     die ("Error".mysqli_connect_error());
    // }

?>